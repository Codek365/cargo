<div class="container">
			<h4 style="color:#11111;height:350px;margin-top:50px"><?php echo $info; ?></h4>
</div>
