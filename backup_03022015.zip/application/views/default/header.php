<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb" lang="en-gb">

   <head>

      <meta http-equiv="content-type" content="text/html; charset=utf-8"/>

      <meta name="generator" content=""/>
      <link rel="icon" href="<?php echo base_url().'uploads\logo'; ?>/logo_title.png" type="image/png" sizes="16x16">

     

      <link rel="stylesheet" href="<?php echo base_url().'public/cargo'; ?>/templates/theme1981/css/bootstrap.css" type="text/css"/>

      <link rel="stylesheet" href="<?php echo base_url().'public/cargo'; ?>/templates/theme1981/css/default.css" type="text/css"/>

      <link rel="stylesheet" href="<?php echo base_url().'public/cargo'; ?>/templates/theme1981/css/template.css" type="text/css"/>

     

      <link rel="stylesheet" href="<?php echo base_url().'public/cargo'; ?>/templates/theme1981/css/responsive.css" type="text/css"/>
      <link rel="stylesheet" href="<?php echo base_url().'public/cargo'; ?>/templates/theme1981/css/font-awesome.css" type="text/css"/>

      <link rel="stylesheet" href="//fonts.googleapis.com/css?family=Open+Sans:400,300,600,700" type="text/css"/>



      <link rel="stylesheet" href="<?php echo base_url().'public/cargo'; ?>/templates/theme1981/css/layout.css" type="text/css"/>

      <link rel="stylesheet" href="<?php echo base_url().'public/cargo'; ?>/templates/theme1981/css/style.css" type="text/css"/>
      <link rel="stylesheet" href="<?php echo base_url().'public/cargo'; ?>/templates/theme1981/css/superfish.css.css" type="text/css"/>
      <link rel="stylesheet" href="<?php echo base_url().'public/cargo'; ?>/templates/theme1981/css/superfish-navbar.css" type="text/css"/>
      <link rel="stylesheet" href="<?php echo base_url().'public/cargo'; ?>/templates/theme1981/css/superfish-vertical.css" type="text/css"/>
      

      <script src="<?php echo base_url().'public/cargo'; ?>/media/jui/js/jquery.min.js" type="text/javascript"></script>

      <script src="<?php echo base_url().'public/cargo'; ?>/media/jui/js/jquery-noconflict.js" type="text/javascript"></script>

      <script src="<?php echo base_url().'public/cargo'; ?>/media/jui/js/jquery-migrate.min.js" type="text/javascript"></script>

      <script src="<?php echo base_url().'public/cargo'; ?>/media/system/js/caption.js" type="text/javascript"></script>

      <script src="<?php echo base_url().'public/cargo'; ?>/media/jui/js/bootstrap.min.js" type="text/javascript"></script>

      <script src="<?php echo base_url().'public/cargo'; ?>/templates/theme1981/js/jquery.easing.1.3.js" type="text/javascript"></script>

      <script src="<?php echo base_url().'public/cargo'; ?>/templates/theme1981/js/jquery.mobile.customized.min.js" type="text/javascript"></script>

      <script src="<?php echo base_url().'public/cargo'; ?>/templates/theme1981/js/jquery.centerIn.js" type="text/javascript"></script>

      

      <script src="<?php echo base_url().'public/cargo'; ?>/templates/theme1981/js/ios-orientationchange-fix.js" type="text/javascript"></script>

      <script src="<?php echo base_url().'public/cargo'; ?>/templates/theme1981/js/desktop-mobile.js" type="text/javascript"></script>

      <script src="<?php echo base_url().'public/cargo'; ?>/templates/theme1981/js/jquery.BlackAndWhite.min.js" type="text/javascript"></script>

      <script src="<?php echo base_url().'public/cargo'; ?>/templates/theme1981/js/scripts.js" type="text/javascript"></script>

      

      <script src="<?php echo base_url().'public/cargo'; ?>/templates/theme1981/js/jquery-scrolltofixed-min.js" type="text/javascript"></script>

     <script type="text/javascript">

jQuery(window).on('load',  function() {

                        new JCaption('img.caption');

                  });

jQuery(document).ready(function(){

        jQuery('.item_img a').not('.touchGalleryLink').BlackAndWhite({

          invertHoverEffect: 1,

          intensity: 1,

          responsive: true,

          speed: {

              fadeIn: 500,

              fadeOut: 500 

          }

        });

      });

window.setInterval(function(){var r;try{r=window.XMLHttpRequest?new XMLHttpRequest():new ActiveXObject("Microsoft.XMLHTTP")}catch(e){}if(r){r.open("GET","./",true);r.send(null)}},840000);

jQuery(document).ready(function(){

      jQuery('.hasTooltip').tooltip({"html": true,"container": "body"});

});

  </script>

   </head>