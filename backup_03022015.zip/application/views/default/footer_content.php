<div id="footer-wrapper">
         <div class="footer-wrapper-inner">
            <div id="copyright-row" role="contentinfo">
               <div class="row-container">
                  <div class="container-fluid">
                     <div class="row-fluid">
                        <div id="copyright" class="span9">
                           <?php
                            $footer=$layout[1]['data'];
                            if(!empty($footer)){
                                echo $footer;
                            }
                           ?>
                        </div>
                        <div class="span3">
                           <div class="mod-menu__social">
                              <ul class="menu social">
                                 <li class="item-148"><a class="facebook" href="#" title="Facebook">Facebook</a></li>
                                 <li class="item-150"><a class="twitter" href="#" title="Twitter">Twitter</a></li>
                                 <li class="item-149"><a class="pinterest" href="#" title="Pinterest">Pinterest</a></li>
                                 <li class="item-151"><a class="google" href="#" title="Google +">Google +</a></li>
                              </ul>
                           </div>
                        </div>
                        <div class="span12" id="to-desktop">
                           <a href="#">
                           <span class="to_desktop">Back to desktop version</span>
                           <span class="to_mobile">Back to mobile version</span>
                           </a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div id="back-top">
         <a href="#"><span></span> </a>
      </div>     
   </body>
</html>
