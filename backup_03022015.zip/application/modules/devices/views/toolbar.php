<div class="btn-group">
	<a href="<?php echo base_url().'admin/devices/index' ?>" class="btn btn-large">Devices List</a>
    <a href="<?php echo base_url().'admin/devices/history' ?>" class="btn btn-large">History</a>                 
</div>