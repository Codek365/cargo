<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$route['devices/index']="devices/index";
$route['devices/history']="devices/history";
