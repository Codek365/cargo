<?php
$lang['L_HELP_DB']="Veritabanlarının listesi";
$lang['L_HELP_PRAEFIX']="Tablo ön eki, tabloların daha kolay filtrelenebilmesini sağlamak için tablo isimlerinin önüne eklenir.";
$lang['L_HELP_ZIP']="GZip ile sıkıştırma - etkin olması önerilir'";
$lang['L_HELP_MEMORYLIMIT']="Byte olarak belirlenir, Scriptin kullanabileceği azami hafızayı belirler
0 = Devre dışı";
$lang['L_MEMORY_LIMIT']="Hafıza sınırı";
$lang['L_HELP_AD1']="Aktiv olduğunda yedekleme dosyaları otomatik olarak silinir.";
$lang['L_HELP_AD3']="Yedekleme dosyalarının maximum sayısı (Otomatik silme için)
0 = kullanılmaz";
$lang['L_HELP_LANG']="Dil seçeneği";
$lang['L_HELP_EMPTY_DB_BEFORE_RESTORE']="Gereksiz kayıtların silinmesi için, geri dönüıümden önce Veritabanlarının boşaltılmasını sağlayabilirsiniz.";
$lang['L_HELP_CRONEXTENDER']="Perlscriptinin dosyabitimi, Standard: '.pl'.";
$lang['L_HELP_CRONSAVEPATH']="Perlskriptinin ayardosyasının adı.";
$lang['L_HELP_CRONPRINTOUT']="Yazı çıktısı kapalı olursa, sonuçlar belirtilmez.
Bu fonksiyon rapor dosyasına bağlı değildir.";
$lang['L_HELP_CRONSAMEDB']="Cronscript için ayarlardaki Veritabanı kullanılsınmı?";
$lang['L_HELP_CRONDBINDEX']="Cronscript için kullanılacak Veritabanını seçiniz.";
$lang['L_HELP_FTPTRANSFER']="Seçildiğinde yedekleme den sonra dosya FTP ile gönderilir.";
$lang['L_HELP_FTPSERVER']="FTP-Sunucusunun adresi.";
$lang['L_HELP_FTPPORT']="FTP-Sunucusunun Portnumarası, Standart: 21.";
$lang['L_HELP_FTPUSER']="FTP-Kullanıcısının adı";
$lang['L_HELP_FTPPASS']="FTP-Kullanıcısının şifresi.";
$lang['L_HELP_FTPDIR']="Dosyanın gönderileceği yer?";
$lang['L_HELP_SPEED']="en düşük ve en yüksek hız, standart: 50'den 5000'e kadar
(daha yüksek hız ayarı çalışmayabilir!).";
$lang['L_SPEED']="Hız";
$lang['L_HELP_CRONEXECPATH']="Perlskriptin bulunduğu alan.
HTTP-Adressinden yola çıkarak (Tarayıcıda).";
$lang['L_CRON_EXECPATH']="Perlskript'in veriyolu";
$lang['L_HELP_CRONCOMPLETELOG']="Aktiv olması durumunda çıktının komplesi complete_log dosyasına kaydedilir. 
Textçıktısı ayarlarına bağlı değildir.";
$lang['L_HELP_FTP_MODE']="Eğer FTP-Transfer esnasında hata oluşursa,lütfen Pasif-Modus yöntemi ile deneyin.";


?>