<?php
$lang['L_RESTORE_TABLES_COMPLETED0']="البدء لآن <b>%d</b> تم انشاء الجداول.";
$lang['L_FILE_MISSING']="لا يستطيع ايجاد الملف";
$lang['L_RESTORE_DB']="قاعدة البيانات '<b>%s</b>' على '<b>%s</b>'.";
$lang['L_RESTORE_COMPLETE']="<b>%s</b> انشاء الجداول.";
$lang['L_RESTORE_RUN1']="<br>البدء لآن  <b>%s</b> of <b>%s</b> تمت الاضافة بنجاح.";
$lang['L_RESTORE_RUN2']="<br>ابدأ الجداول  '<b>%s</b>'اعادة.<br><br>";
$lang['L_RESTORE_COMPLETE2']="<b>%s</b> ادراج سجلات.";
$lang['L_RESTORE_TABLES_COMPLETED']="البدء لآن <b>%d</b> of <b>%d</b> تم انشاء الجداول.";
$lang['L_RESTORE_TOTAL_COMPLETE']="<br><b>تهانينا.</b><br><br>تمت الان استعادة قاعدة البيانات.<br>تم استعادة جميع ملفات النسخ الاحتياطي.<br><br>انتهت العملية. :-)";
$lang['L_DB_SELECT_ERROR']="<br>مشكلة:<br>حدد قاعدة البيانات <b>";
$lang['L_DB_SELECT_ERROR2']="</b> فشل!";
$lang['L_FILE_OPEN_ERROR']="خطأ: لا يمكن فتح الملف.";
$lang['L_PROGRESS_OVER_ALL']="التقدم الشامل";
$lang['L_BACK_TO_OVERVIEW']="تفاصيل عامة لقاعدة البيانات";
$lang['L_RESTORE_RUN0']="<br>البدء لآن<b>%s</b> تمت اضافة السجلات بنجاح.";
$lang['L_UNKNOWN_SQLCOMMAND']="مجهول SQL-امر";
$lang['L_NOTICES']="ملاحظات

";


?>