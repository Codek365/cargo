<?php
$lang['L_INSTALLFINISHED']="<br>Cài đặt thành công  --> <a href=\"index.php\">Bắt đầu MySQLDumper</a><br>";
$lang['L_INSTALL_TOMENU']="Quay lại menu chính";
$lang['L_INSTALLMENU']="Menu chính";
$lang['L_STEP']="SBước";
$lang['L_INSTALL']="Cài đặt";
$lang['L_UNINSTALL']="Gỡ cài đặt";
$lang['L_TOOLS']="Công cụ";
$lang['L_EDITCONF']="Sửa cấu hình";
$lang['L_OSWEITER']="Tiếp tục (bỏ qua không Lưu)";
$lang['L_ERRORMAN']="<strong>Lỗi trong khi Lưu cấu hình!</strong><br>Sửa lại File ";
$lang['L_MANUELL']="bằng tay";
$lang['L_CREATEDIRS']="Tạo ra những thư mục";
$lang['L_INSTALL_CONTINUE']="Tiếp tục với sự cài đặt";
$lang['L_CONNECTTOMYSQL']="Kết nối tới MySQL ";
$lang['L_DBPARAMETER']="Những tham số Cơ sở dữ liệu";
$lang['L_CONFIGNOTWRITABLE']="Tôi không thể viết vào file \"config.php\".
Hãy dùng trình FTP của bạn và chmod afile này thành 0777.";
$lang['L_DBCONNECTION']="Kết nối Cơ sở dữ liệu";
$lang['L_CONNECTIONERROR']="Lỗi: Không thể nối.";
$lang['L_CONNECTION_OK']="Kết nối Cơ sở dữ liệu được thiết lập.";
$lang['L_SAVEANDCONTINUE']="Lưu lại và tiếp tục sự cài đặt";
$lang['L_CONFBASIC']="Tham số Cơ bản";
$lang['L_INSTALL_STEP2FINISHED']="Những tham số Cơ sở dữ liệu được Lưu lại thành công.";
$lang['L_INSTALL_STEP2_1']="Tiếp tục cài đặt với những thiết đặt mặc định";
$lang['L_LASTSTEP']="Kết thúc Cài đặt";
$lang['L_FTPMODE']="Tạo ra những thư mục cần thiết Trong safe-mode";
$lang['L_IDOMANUAL']="Tôi tạo ra những thư mục của tôi";
$lang['L_DOFROM']="bắt đầu từ";
$lang['L_FTPMODE2']="Tạo các thư mục với FTP:";
$lang['L_CONNECT']="kết nối";
$lang['L_DIRS_CREATED']="Các thư mục được tạo ra và được chấp nhận.";
$lang['L_CONNECT_TO']="kết nối tới";
$lang['L_CHANGEDIR']="đổi thư mục";
$lang['L_CHANGEDIRERROR']="không thể đổi thư mục";
$lang['L_FTP_OK']="tham số FTP được chấp nhận";
$lang['L_CREATEDIRS2']="Tạo các thư mục";
$lang['L_FTP_NOTCONNECTED']="Kết nối FTP không được thiết lập!";
$lang['L_CONNWITH']="Kết nối Với";
$lang['L_ASUSER']="như người sử dụng";
$lang['L_NOTPOSSIBLE']="không thể";
$lang['L_DIRCR1']="tạo thư mục work";
$lang['L_DIRCR2']="tạo thư mục backup";
$lang['L_DIRCR4']="tạo thư mục log";
$lang['L_DIRCR5']="tạo thư mục configuration";
$lang['L_INDIR']="đang ở thư mục";
$lang['L_CHECK_DIRS']="Kiểm tra các thư mục";
$lang['L_DISABLEDFUNCTIONS']="Vô hiệu hóa những tính năng";
$lang['L_NOFTPPOSSIBLE']="Bạn không có những tính năng FTP !";
$lang['L_NOGZPOSSIBLE']="Bạn không có những tính năng nén !";
$lang['L_UI1']="Tất cả các thư mục làm việc mà có thể chứa đựng những sao lưu sẽ được xóa.";
$lang['L_UI2']="Bạn chắc chắn bạn muốn điều đó?";
$lang['L_UI3']="không, bỏ qua ngay lập tức";
$lang['L_UI4']="có, cứ tiếp tục";
$lang['L_UI5']="xóa những thư mục làm việc";
$lang['L_UI6']="mọi thứ đã bị xóa thành công.";
$lang['L_UI7']="Xin xóa thư mục script";
$lang['L_UI8']="lên mức trên";
$lang['L_UI9']="Có lỗi, không thể xóa</p>Lỗi với thư mục ";
$lang['L_IMPORT']="Nhập Cấu hình";
$lang['L_IMPORT3']="Cấu hình được tải ...";
$lang['L_IMPORT4']="Đã ghi cấu hình.";
$lang['L_IMPORT5']="Chạy MySQLDumper";
$lang['L_IMPORT6']="Menu cài đặt";
$lang['L_IMPORT7']="Upload cấu hình";
$lang['L_IMPORT8']="quay lại để upload";
$lang['L_IMPORT9']="Đây không là một sao lưu cấu hình !";
$lang['L_IMPORT10']="Cấu hình được upload thành công ...";
$lang['L_IMPORT11']="<strong>Lỗi: </strong>Có vấn đề khi đang viết sql_statements";
$lang['L_IMPORT12']="<strong>Lỗi: </strong>Có vấn đề khi đang viết config.php";
$lang['L_INSTALL_HELP_PORT']="(để trống = Cổng mặc định)";
$lang['L_INSTALL_HELP_SOCKET']="(để trống = Socket mặc định)";
$lang['L_TRYAGAIN']="Thử lại";
$lang['L_SOCKET']="Socket";
$lang['L_PORT']="Cổng";
$lang['L_FOUND_DB']="tìm thấy db";
$lang['L_FM_FILEUPLOAD']="Upload file";
$lang['L_PASS']="Password";
$lang['L_NO_DB_FOUND_INFO']="Kết nối tới cSDL được thiết lập thành công.<br>
Dữ liệu thành viên hợp lệ và được MySQL-Server chấp nhận.<br>
Nhưng MySQLDumper không thể tìm thấy bất kỳ cơ sở dữ liệu nào.<br>
Dò tìm tự động qua script bị cấm trên một vài server.<br>
Bạn phải vào databasename của bạn bằng tay sau khi sự cài đặt (thì) kết thúc.
Click \"cấu hình\" \"Tham số Kết nối - hiển thị\" và nhập tên CSDL đó.";
$lang['L_SAFEMODEDESC']="Vì PHP đang chạy trong chế độ safe_mode nên bạn phải tạo thư mục bằng cách sử dụng chương trình FTP:


";
$lang['L_ENTER_DB_INFO']="First click the button \"Connect to MySQL\". Only if no database could be detected you need to provide a database name here.";


?>