<?php
$lang['L_HELP_DB']="Đây là danh sách (của) tất cả các cơ sở dữ liệu";
$lang['L_HELP_PRAEFIX']="tiền tố là một chuỗi ký tự bắt đầu cho một tên bảng, nó làm việc  như một bộ lọc.";
$lang['L_HELP_ZIP']="Nén với GZip - nên 'kích hoạt'";
$lang['L_HELP_MEMORYLIMIT']="Số lượng tối đã (tính bằng Byte) cho script
0 = ngưng kích hoạt";
$lang['L_MEMORY_LIMIT']="Giới hạn bộ nhớ";
$lang['L_HELP_AD1']="Nếu được kích hoạt, file sao lưu sẽ được tự động xóa.";
$lang['L_HELP_AD3']="số lượng file sao lưu tối đa (sẽ bị xóa tự động)
0 = không khống chế";
$lang['L_HELP_LANG']="select your language";
$lang['L_HELP_EMPTY_DB_BEFORE_RESTORE']="Để loại trừ dữ liệu vô ích bạn có thể chỉ dẫn làm trống rỗng cơ sở dữ liệu trước khi khôi phục";
$lang['L_HELP_CRONEXTENDER']="Phần mở rộng của mã nguồn Perl, mặc định là '.pl'";
$lang['L_HELP_CRONSAVEPATH']="Tên của file cấu hình cho mã nguồn Perl";
$lang['L_HELP_CRONPRINTOUT']="Nếu ngưng kích hoạt, kết quả sẽ không xxược in ra màn hình.
Nó độc lập với việc in trong logfile.";
$lang['L_HELP_CRONSAMEDB']="Use same database in Cron job like configured under Database?";
$lang['L_HELP_CRONDBINDEX']="choose the database for Cron job";
$lang['L_HELP_FTPTRANSFER']="nếu kích hoạt, file sẽ được gửi qua FTP.";
$lang['L_HELP_FTPSERVER']="Địa chỉ của FTP-Server";
$lang['L_HELP_FTPPORT']="Cổng của FTP-Server, chuẩn là: 21";
$lang['L_HELP_FTPUSER']="nhập username truy cập FTP";
$lang['L_HELP_FTPPASS']="nhập mật khẩu truy cập FTP";
$lang['L_HELP_FTPDIR']="thư mục upload ở đâu? nhập đường dẫn!";
$lang['L_HELP_SPEED']="Tốc độ tối thiểu và tối đa, mặc định là 50 tới 5000";
$lang['L_SPEED']="Điều khiển tốc độ";
$lang['L_HELP_CRONEXECPATH']="Nơi của Perl scripts.
Xuất phát từ HTTP-Address (giống địa chỉ ở trình duyệt)
được sử dụng địa chỉ tuyệt đối hay tương đối.";
$lang['L_CRON_EXECPATH']="Đường dẫn của Perl scripts";
$lang['L_HELP_CRONCOMPLETELOG']="Khi được kích hoạt, đường ra đầy đủ được ghi trong complete_log-file.
Cái này độc lập với văn bản đang in";
$lang['L_HELP_FTP_MODE']="Khi có vấn đề xuất hiện với việc chuyển qua FTP, thử sử dụng chế độ bị động (passive mode).


";


?>