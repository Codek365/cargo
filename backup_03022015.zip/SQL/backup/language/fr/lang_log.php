<?php
$lang['L_LOG_DELETE']="Supprimer le journal";
$lang['L_LOGFILEFORMAT']="Format du journal";
$lang['L_LOGFILENOTWRITABLE']="Écriture du Journal impossible!";
$lang['L_NOREVERSE']="Montrer les entrées les plus anciennes en premier";
$lang['L_REVERSE']="Montrer les entrées les plus récentes en premier";


?>