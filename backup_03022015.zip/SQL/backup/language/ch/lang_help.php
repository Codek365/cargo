<?php
$lang['L_HELP_DB']="Das isch d Lischte vo de vorhandene Datebanke.";
$lang['L_HELP_PRAEFIX']="Dr Präfix isch e Zeichefolg für d Aafang vo Tabälle, wo als Filter fungiert.";
$lang['L_HELP_ZIP']="Kompression mit GZip - emfohle isch 'aktiviert'.";
$lang['L_HELP_MEMORYLIMIT']="Das isch di maximali Grössi i Bytes, wo das Skript a Speicher überchunnt. 0 = deaktiviert";
$lang['L_MEMORY_LIMIT']="Spiichergränze";
$lang['L_HELP_AD1']="Wänn aktiviert, dänn werdet automatisch Backup-Dateie glöscht.";
$lang['L_HELP_AD3']="Di maximali Aazahl vo Dateie, wo im Backup-Verzeichnis sii dörfed (für Autodelete). 0 = deaktiviert";
$lang['L_HELP_LANG']="Stellt uf di gwünschti Sprach.";
$lang['L_HELP_EMPTY_DB_BEFORE_RESTORE']="Zum überflüssigi Date eliminiere, cha me anwiise, d Datebank vor de Reschtaurierig komplett z lääre.";
$lang['L_HELP_CRONEXTENDER']="D Endig vom Perlscript, Standard isch '.pl'.";
$lang['L_HELP_CRONSAVEPATH']="De Name vo de Konfigurationsdatei fürs Perlskript.";
$lang['L_HELP_CRONPRINTOUT']="Wänn d Textuusgab abgschaltet isch, wird kei Text meh ausgeh. Diä Funktion isch unabhängig vo de Log-Uusgab.";
$lang['L_HELP_CRONSAMEDB']="Söll di gliichi Datebank für de Cronjob wiä i de Iischtellige brucht wärde?";
$lang['L_HELP_CRONDBINDEX']="Wähl d Datebank für de Cronjob";
$lang['L_HELP_FTPTRANSFER']="Wänn aktiviert, wird nachem Backup diä Datei per FTP gschickt.";
$lang['L_HELP_FTPSERVER']="D Adrässe vom FTP-Server.";
$lang['L_HELP_FTPPORT']="Port vom FTP-Server. Standard: 21";
$lang['L_HELP_FTPUSER']="Gib de Benutzername vo de FTP-Verbindig a.";
$lang['L_HELP_FTPPASS']="Gibs s Passwort vo de FTP-Verbindig a.";
$lang['L_HELP_FTPDIR']="Wohäre söll diä Datei gschickt wärde?";
$lang['L_HELP_SPEED']="Minimali und maximali Gschwindigkeit. Standard isch 50 bis 5000. (Z höchi Gschwindigkeite chönned zu Timeouts führe!)";
$lang['L_SPEED']="Gschwindigkeitskontrolle";
$lang['L_HELP_CRONEXECPATH']="Dr Ort, wo die Perlskripts ligged. Usgangspunkt isch d HTTP-Adresse (also im Browser). Erlaubt sind absoluti und relativi Pfadaagabe.";
$lang['L_CRON_EXECPATH']="Pfad vo de Perlskripts";
$lang['L_HELP_CRONCOMPLETELOG']="Wänn diä Funktion aktiviert isch, wird di kompletti Usgab im complete_log gschribe. Diä Funtion isch unabhängig vo de Textusgab.";
$lang['L_HELP_FTP_MODE']="Wänn Problem bi de FTP-Überträgig uftauched, versueched Si de passivi FTP-Modus";


?>