<?php
$lang['L_RESTORE_TABLES_COMPLETED0']="Finora sono stati create <b>%d</b> tabelle.";
$lang['L_FILE_MISSING']="impossibile trovare il file";
$lang['L_RESTORE_DB']="Database '<b>%s</b>' sul Server '<b>%s</b>'.";
$lang['L_RESTORE_COMPLETE']="<b>%s</b> tabelle sono state create.";
$lang['L_RESTORE_RUN1']="<br>Finora sono stati aggiunti con successo da <b>%s</b> a <b>%s</b> record.";
$lang['L_RESTORE_RUN2']="<br>Sto popolando la tabella '<b>%s</b>'.<br><br>";
$lang['L_RESTORE_COMPLETE2']="<b>%s</b> record sono stati inseriti.";
$lang['L_RESTORE_TABLES_COMPLETED']="Finora sono state create da <b>%d</b> a <b>%d</b> tabelle.";
$lang['L_RESTORE_TOTAL_COMPLETE']="<br><b>Congratulazioni!</b><br><br>Il database è stato ripristinato completamente.<br>Tutti i file del backup sono stati inseriti con successo.<br><br>Hai finito. :-)";
$lang['L_DB_SELECT_ERROR']="<br>Errore:<br>Selezione del database <b>";
$lang['L_DB_SELECT_ERROR2']="</b> fallito!";
$lang['L_FILE_OPEN_ERROR']="Errore: impossibile aprire il file.";
$lang['L_PROGRESS_OVER_ALL']="Progresso totale";
$lang['L_BACK_TO_OVERVIEW']="Riepilogo database";
$lang['L_RESTORE_RUN0']="<br>Finora sono stati aggiunti con successo da <b>%s</b> a <b>%s</b> record.";
$lang['L_UNKNOWN_SQLCOMMAND']="Comando SQL sconosciuto.";
$lang['L_NOTICES']="Avvisi";


?>